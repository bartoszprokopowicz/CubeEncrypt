# CubeEncrypt
Package for python3 to encrypt and decrypt strings